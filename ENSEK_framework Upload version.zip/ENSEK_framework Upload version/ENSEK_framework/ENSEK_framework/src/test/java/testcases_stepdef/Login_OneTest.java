package testcases_stepdef;

import BaseClass.baseUtils;
import PageObjectory.Login_OnePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Login_OneTest extends baseUtils {
	Login_OnePage bop= new Login_OnePage(driver);
	
	@Given("^I am on the homepage and I click on Login tab$")
	public void i_am_on_the_homepage_and_I_click_on_Login_tab() throws Throwable {
		bop.loginLink();
	}

	@When("^I click Login button and nothing should happen$")
	public void i_click_Login_button_and_nothing_should_happen() throws Throwable {
		bop.logInBtn();
	}


}
