package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.BuyingElectricityPage;
import PageObjectory.BuyinggasPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BuyingElectricityTest extends baseUtils {
	BuyingElectricityPage bgp= new BuyingElectricityPage(driver);
	BuyinggasPage bggp= new BuyinggasPage(driver);
	
	@Given("^On the electricity section I type in the \"([^\"]*)\"$")
	public void on_the_electricity_section_I_type_in_the(String NumberofUnitsRequiredofElectricity) throws Throwable {
	    bgp.NumberofUnitsRequired(NumberofUnitsRequiredofElectricity);
	}

	@Given("^I click electricity Buy button$")
	public void i_click_electricity_Buy_button() throws Throwable {
		bgp.ElectricityBuyBtn();
	}
	
	@Given("^I verify that there is a message showing \"([^\"]*)\"$")
	public void i_verify_that_there_is_a_message_showing(String MessageDisplay) throws Throwable {
		Assert.assertEquals(bgp.MessageDisplay(), MessageDisplay);
	}

	@When("^I press the Buy More button$")
	public void i_press_the_Buy_More_button() throws Throwable {
	    bgp.Buymorebtn();
	    
	}

	@Then("^the Number of Units Required of Electricity shows \"([^\"]*)\"$")
	public void the_Number_of_Units_Required_of_Electricity_shows(String NumberOfUnitsDisplay) throws Throwable {
		Assert.assertEquals(bgp.NumberOfUnitsDisplay(), NumberOfUnitsDisplay);
		Thread.sleep(1000);
		bggp.ResetBtn();
	    Thread.sleep(1000);
	}


}
