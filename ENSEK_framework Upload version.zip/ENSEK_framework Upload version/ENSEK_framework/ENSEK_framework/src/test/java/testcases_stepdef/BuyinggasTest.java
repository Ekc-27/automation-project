package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.BuyEnergypage;
import PageObjectory.BuyinggasPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BuyinggasTest extends baseUtils {
	BuyEnergypage bep= new BuyEnergypage(driver);
	BuyinggasPage bgp= new BuyinggasPage(driver);
	
	@Given("^I am on the Energy page$")
	public void i_am_on_the_Energy_page() throws Throwable {
		bep.BuyEnergybtn();
		Assert.assertTrue(true, bep.BuyEnergyDisplay());
	}

	@Given("^On the gas section I type in the \"([^\"]*)\"$")
	public void on_the_gas_section_I_type_in_the(String NumberofUnitsRequired) throws Throwable {
		bgp.NumberofUnitsRequired(NumberofUnitsRequired);
	}

	@Given("^I click gas Buy button$")
	public void i_click_gas_Buy_button() throws Throwable {
	    bgp.GasBuyBtn();
	}

	@When("^I go back to the previous page$")
	public void i_go_back_to_the_previous_page() throws Throwable {
		bgp.NaviagteBack();
	}

	@Then("^The Number of Units Required of Gas shows \"([^\"]*)\"$")
	public void the_Number_of_Units_Required_of_Gas_shows(String Availability) throws Throwable {
		Assert.assertEquals(bgp.Availability(), Availability);
		bgp.ResetBtn();
	    Thread.sleep(1000);
	}

	@Given("^I verify that sale has been confirmed with the message showing \"([^\"]*)\"$")
	public void i_verify_that_sale_has_been_confirmed_with_the_message_showing(String Status) throws Throwable {
		Assert.assertEquals(bgp.SaleConfirmed(), Status);
	}

}
