package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.BuyEnergypage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BuyEnergyTest extends baseUtils {
	BuyEnergypage bep;

	@Given("^I go to homepage$")
	public void i_go_to_homepage() throws Throwable {
		String gettitle = driver.getTitle();
		System.out.println("Title displays as : " + gettitle);
		Assert.assertTrue(true, gettitle);
	}

	@When("^I click Buy energy$")
	public void i_click_Buy_energy() throws Throwable {
		bep = new BuyEnergypage(driver);
		bep.BuyEnergybtn();
	}

	@Then("^I should arrive in the Buy Energy page$")
	public void i_should_arrive_in_the_Buy_Energy_page() throws Throwable {
		Assert.assertTrue(true, bep.BuyEnergyDisplay());
	}

}
