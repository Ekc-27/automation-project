package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.Aboutuspage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class AboutUsTest extends baseUtils {
	Aboutuspage bep= new Aboutuspage(driver);
	
	@Given("^I am on the homepage and I click on Learn more button$")
	public void i_am_on_the_homepage_and_I_click_on_Learn_more_button() throws Throwable {
	   bep.LearnMore();
	}

	@Then("^I should arrive in the About us page$")
	public void i_should_arrive_in_the_About_us_page() throws Throwable {
		Assert.assertTrue(true, bep.AboutUsPage());
	}

	@Then("^I verify the message in the page 'Learn a little more about us'$")
	public void i_verify_the_message_in_the_page_Learn_a_little_more_about_us() throws Throwable {
		Assert.assertTrue(true, bep.Learnalittlemoreaboutus());
	}

	@Then("^I verify the message 'Now, nearly (\\d+) years later, our team has grown to over (\\d+) strong\\. We now enable (\\d+) energy suppliers and millions of their customers to change the energy industry for the better\\.'$")
	public void i_verify_the_message_Now_nearly_years_later_our_team_has_grown_to_over_strong_We_now_enable_energy_suppliers_and_millions_of_their_customers_to_change_the_energy_industry_for_the_better(int arg1, int arg2, int arg3) throws Throwable {
		Assert.assertTrue(true, bep.TeamGrown());
	}



}
