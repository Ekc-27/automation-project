package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.SellEnergypage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class SellingEnergyTest extends baseUtils {
	SellEnergypage sep= new SellEnergypage(driver);
	
	@Given("^I am on the Sell Energy page and  I click on the button Sell Energy$")
	public void i_am_on_the_Sell_Energy_page_and_I_click_on_the_button_Sell_Energy() throws Throwable {
		sep.SellEnergybtn();
	}

	@Then("^I should arrive in the Sell Energy page which is under maintenance$")
	public void i_should_arrive_in_the_Sell_Energy_page_which_is_under_maintenance() throws Throwable {
		Assert.assertTrue(true, sep.maintenanceDisplay());
	}

	@Then("^I verify the message in the page 'Here to sell some energy\\?'$")
	public void i_verify_the_message_in_the_page_Here_to_sell_some_energy() throws Throwable {
		Assert.assertTrue(true, sep.SellEnergyDisplay());
	}



}
