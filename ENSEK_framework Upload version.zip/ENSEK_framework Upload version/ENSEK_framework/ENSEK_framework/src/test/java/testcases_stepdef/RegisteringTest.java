package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.RegisterPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisteringTest extends baseUtils {
	RegisterPage rp= new RegisterPage(driver);
	
	@Given("^I am on the homepage and I click on Register$")
	public void i_am_on_the_homepage_and_I_click_on_Register() throws Throwable {
	    
	 rp.RegisterLink();
	}

	@Given("^I click on Register button on the register page$")
	public void i_click_on_Register_button_on_the_register_page() throws Throwable {
	    rp.Registerbtn();
	 
	}

	@Given("^I confirm that the message is shown 'The Email field is required\\.'$")
	public void i_confirm_that_the_message_is_shown_The_Email_field_is_required() throws Throwable {
		Assert.assertTrue(true, rp.EmailText());
	 
	}

	@Given("^I confirm that the message is shown 'The Password field is required\\.'$")
	public void i_confirm_that_the_message_is_shown_The_Password_field_is_required() throws Throwable {
	    
		Assert.assertTrue(true, rp.PasswordText());
	}

	@When("^I type in email \"([^\"]*)\"$")
	public void i_type_in_email(String email) throws Throwable {
	    rp.EmailInput(email);
	 
	}

	@When("^type in Password \"([^\"]*)\"$")
	public void type_in_Password(String Password) throws Throwable {
	    rp.Password_Input(Password);
	 
	}

	@When("^type in Confirm Password \"([^\"]*)\"$")
	public void type_in_Confirm_Password(String ConfirmPassword) throws Throwable {
	    rp.ConfirmPassword_Input(ConfirmPassword);
	    Thread.sleep(5000);
	    rp.Registerbtn();
	    Thread.sleep(5000);
	 
	}

	@Then("^I verify the message in the page \"([^\"]*)\"$")
	public void i_verify_the_message_in_the_page(String PasswordMessage) throws Throwable {
		Thread.sleep(1000);
		Assert.assertEquals(rp.PasswordStrength(), PasswordMessage);
	}


}
