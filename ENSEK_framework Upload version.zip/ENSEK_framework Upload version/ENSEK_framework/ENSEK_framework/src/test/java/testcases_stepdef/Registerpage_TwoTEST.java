package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.RegisterPage;
import cucumber.api.java.en.Then;

public class Registerpage_TwoTEST extends baseUtils {
	RegisterPage rp= new RegisterPage(driver);
	
	@Then("^I verify the error message in the page \"([^\"]*)\"$")
	public void i_verify_the_error_message_in_the_page(String Error_PasswordMessage) throws Throwable {
	   Assert.assertEquals(rp.PasswordError(), Error_PasswordMessage);
	   Thread.sleep(1000);
	}

}
