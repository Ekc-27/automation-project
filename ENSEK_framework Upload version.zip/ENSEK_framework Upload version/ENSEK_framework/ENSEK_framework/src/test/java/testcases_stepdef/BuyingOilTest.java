package testcases_stepdef;

import org.testng.Assert;

import BaseClass.baseUtils;
import PageObjectory.BuyingOilPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BuyingOilTest extends baseUtils {
	BuyingOilPage bop= new BuyingOilPage(driver);
	
	@Given("^On the oil section I type in the NumberofUnitsRequiredofOil_ten \"([^\"]*)\"$")
	public void on_the_oil_section_I_type_in_the_NumberofUnitsRequiredofOil_ten(String NumberofUnitsRequiredofOil_10) throws Throwable {
		bop.NumberofUnitsRequired(NumberofUnitsRequiredofOil_10);
	}

	@Given("^I click Oil Buy button$")
	public void i_click_Oil_Buy_button() throws Throwable {
	    bop.OilBuyBtn();
	}

	@Given("^I verify that there is a message showing MessageDisplay_ten\"([^\"]*)\"$")
	public void i_verify_that_there_is_a_message_showing_MessageDisplay_ten(String MessageDisplay_10) throws Throwable {
	   Assert.assertEquals(bop.MessageDisplay(), MessageDisplay_10);
	}

	@When("^On the oil section I type in the NumberofUnitsRequiredofOil_four\"([^\"]*)\"$")
	public void on_the_oil_section_I_type_in_the_NumberofUnitsRequiredofOil_four(String NumberofUnitsRequiredofOil_4) throws Throwable {
		bop.NumberofUnitsRequired(NumberofUnitsRequiredofOil_4);
	}

	@When("^I verify that there is a message showing MessageDisplay_four\"([^\"]*)\"$")
	public void i_verify_that_there_is_a_message_showing_MessageDisplay_four(String MessageDisplay_4) throws Throwable {
		Assert.assertEquals(bop.MessageDisplay(), MessageDisplay_4);
	}

	@Then("^the Number of Units Required of Oil shows \"([^\"]*)\"$")
	public void the_Number_of_Units_Required_of_Oil_shows(String NumberOfUnitsDisplay) throws Throwable {
		Assert.assertEquals(bop.NumberOfUnitsDisplay(), NumberOfUnitsDisplay);
		Thread.sleep(1000);
		bop.ResetBtn();
	    Thread.sleep(1000);
	}





}
