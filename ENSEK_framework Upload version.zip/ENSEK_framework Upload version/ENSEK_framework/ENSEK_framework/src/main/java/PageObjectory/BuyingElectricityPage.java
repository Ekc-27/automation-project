package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class BuyingElectricityPage extends baseUtils {

	public BuyingElectricityPage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//td[contains(text(),'Electricity')]//ancestor::tbody//tr[3]//td//input[@id='energyType_AmountPurchased']")
	private WebElement NumberofUnitsRequired;
	
	public void NumberofUnitsRequired(String value) throws InterruptedException{
		NumberofUnitsRequired.clear();
		NumberofUnitsRequired.sendKeys(value);
		Thread.sleep(1000);
	}
	
	@FindBy(xpath = "//div[@class='container text-center']/div/p")
	private WebElement MessageDisplay;
	
	public String MessageDisplay(){
		return MessageDisplay.getText();
	}
	
	//@FindBy(xpath = "//body/div[@class='container body-content']/p[2]")
	
	@FindBy(xpath = "//a[contains(text(),'Buy more »')]")
	private WebElement Buymore;
	
	public void Buymorebtn() {
		Buymore.click();
	}
	
	@FindBy(xpath = "//td[contains(text(),'Electricity')]//ancestor::tbody//tr[3]//td[3]")
	private WebElement NumberOfUnitsDisplay;
	
	public String NumberOfUnitsDisplay(){
		return NumberOfUnitsDisplay.getText();
	}
	
	
	@FindBy(xpath = "//td[contains(text(),'Electricity')]//ancestor::tbody//tr[3]/td/input[@name='Buy']")
	private WebElement ElectricityBuyBtn;
	
	public void ElectricityBuyBtn() {
		ElectricityBuyBtn.click();
	}
}
