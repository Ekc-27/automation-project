package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class Aboutuspage extends baseUtils {

	public Aboutuspage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Learn more »')]")
	private WebElement LearnMore;
	
	public void LearnMore() {
		LearnMore.click();
	}
	
	@FindBy(xpath = "//h2[contains(text(),'Buy Energy')]")
	private WebElement BuyEnergyDisplay;
	
	public String BuyEnergyDisplay(){
		return BuyEnergyDisplay.getText();
	}
	
	@FindBy(xpath = "//h3[contains(text(),'Learn a little more about us')]")
	private WebElement Learnalittlemoreaboutus;
	
	public String Learnalittlemoreaboutus(){
		return Learnalittlemoreaboutus.getText();
	}
	
	@FindBy(xpath = "//p[contains(text(),'Now, nearly 10 years later, our team has grown to ')]")
	private WebElement TeamGrown;
	
	public String TeamGrown(){
		return TeamGrown.getText();
	}
	
	@FindBy(xpath = "//h2[contains(text(),'About ENSEK Energy Corp..')]")
	private WebElement AboutUsPage;
	
	public String AboutUsPage(){
		return AboutUsPage.getText();
	}

}
