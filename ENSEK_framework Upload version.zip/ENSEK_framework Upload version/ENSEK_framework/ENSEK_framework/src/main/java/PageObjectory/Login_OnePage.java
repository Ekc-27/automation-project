package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class Login_OnePage extends baseUtils {

	public Login_OnePage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@id='loginLink']")
	private WebElement loginLink;
	
	public void loginLink() {
		loginLink.click();
	}
	
	@FindBy(xpath = "//input[@value='Log in']")
	private WebElement logInBtn;
	
	public void logInBtn() {
		logInBtn.click();
	}

}
