package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class BuyinggasPage extends baseUtils {

	public BuyinggasPage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//td[contains(text(),'Gas')]//ancestor::tbody//tr[1]//td//input[@id='energyType_AmountPurchased']")
	
	// @FindBy(xpath = "//body/div[@class='container body-content']/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[4]")
	private WebElement NumberofUnitsRequired;
	
	public void NumberofUnitsRequired(String value) throws InterruptedException{
		NumberofUnitsRequired.clear();
		NumberofUnitsRequired.sendKeys(value);
		Thread.sleep(1000);
	}

	
	@FindBy(xpath = "//td[contains(text(),'Gas')]//ancestor::tbody//tr[1]/td/input[@name='Buy']")
	private WebElement GasBuyBtn;
	
	public void GasBuyBtn() {
		GasBuyBtn.click();
	}
	
	@FindBy(xpath = "//h2[contains(text(),'Sale Confirmed!')]")
	private WebElement SaleConfirmed;
	
	public String SaleConfirmed(){
		return SaleConfirmed.getText();
	}
	
	public void NaviagteBack(){
		driver.navigate().back();
	}
	
	@FindBy(xpath = "//td[contains(text(),'Gas')]//parent::tr//td[contains(text(),'Not Available')]")
	private WebElement Availability;
	
	public String Availability(){
		return Availability.getText();
	}
	
	@FindBy(name = "Reset")
	private WebElement ResetBtn;
	
	public void ResetBtn() {
		ResetBtn.click();
	}
}
