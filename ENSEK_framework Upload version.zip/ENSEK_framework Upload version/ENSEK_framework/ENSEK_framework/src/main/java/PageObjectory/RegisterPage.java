package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class RegisterPage extends baseUtils {

	public RegisterPage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@id='registerLink']")
	private WebElement RegisterLink;
	
	public void RegisterLink() {
		RegisterLink.click();
	}
	
	@FindBy(xpath = "//input[@value='Register']")
	private WebElement Registerbtn;
	
	public void Registerbtn() {
		Registerbtn.click();
	}
	
	@FindBy(xpath = "//li[contains(text(),'The Email field is required.')]")
	private WebElement EmailText;
	
	public String EmailText(){
		return EmailText.getText();
	}
	
	@FindBy(xpath = "//li[contains(text(),'The Password field is required.')]")
	private WebElement PasswordText;
	
	public String PasswordText(){
		return PasswordText.getText();
	}
	
	@FindBy(xpath = "//input[@id='Email']")
	private WebElement Email_Input;
	
	public void EmailInput(String value){
		Email_Input.clear();
		Email_Input.sendKeys(value);
	}
	
	@FindBy(xpath = "//input[@id='Password']")
	private WebElement Password_Input;
	
	public void Password_Input(String value){
		Password_Input.clear();
		Password_Input.sendKeys(value);
	}
	
	@FindBy(xpath = "//input[@id='ConfirmPassword']")
	private WebElement ConfirmPassword_Input;
	
	public void ConfirmPassword_Input(String value){
		ConfirmPassword_Input.clear();
		ConfirmPassword_Input.sendKeys(value);
	}
	
	@FindBy(xpath = "//li[contains(text(),'The Password must be at least 6 characters long.')]")
	private WebElement PasswordStrength;
	
	public String PasswordStrength(){
		return PasswordStrength.getText();
	}
	
	@FindBy(xpath = "//li[contains(text(),'Passwords must have at least one non letter or digit character.')]")
	private WebElement PasswordError;
	
	public String PasswordError(){
		return PasswordError.getText();
	}
}
