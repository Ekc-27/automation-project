package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class SellEnergypage extends baseUtils {

	public SellEnergypage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Sell energy »')]")
	private WebElement SellEnergy;
	
	public void SellEnergybtn() {
		SellEnergy.click();
	}
	
	
	@FindBy(xpath = "//h2[contains(text(),'Here to sell some energy?')]")
	private WebElement SellEnergyDisplay;
	
	public String SellEnergyDisplay(){
		return SellEnergyDisplay.getText();
	}
	
	@FindBy(xpath = "//div[2]/div[1]/img[1]")
	private WebElement maintenanceDisplay;
	
	public String maintenanceDisplay(){
		return maintenanceDisplay.getText();
	}
	
	

}
