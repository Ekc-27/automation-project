package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class BuyingOilPage extends baseUtils {

	public BuyingOilPage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//td[contains(text(),'Oil')]//ancestor::tbody//tr[4]//td//input[@id='energyType_AmountPurchased']")
	private WebElement NumberofUnitsRequired;
	
	public void NumberofUnitsRequired(String value) throws InterruptedException{
		NumberofUnitsRequired.clear();
		NumberofUnitsRequired.sendKeys(value);
		Thread.sleep(1000);
	}

	
	@FindBy(xpath = "//td[contains(text(),'Oil')]//ancestor::tbody//tr[4]/td/input[@name='Buy']")
	private WebElement OilBuyBtn;
	
	public void OilBuyBtn() {
		OilBuyBtn.click();
	}
	
	
	public void NaviagteBack(){
		driver.navigate().back();
	}
	
	@FindBy(name = "Reset")
	private WebElement ResetBtn;
	
	public void ResetBtn() {
		ResetBtn.click();
	}
	
	// @FindBy(xpath = "//a[contains(text(),'Buy more »')]")
	
	@FindBy(xpath = "//body/div[@class='container body-content']/p[2]")
	private WebElement Buymore;
	
	public void Buymorebtn() {
		Buymore.click();
	}
	
	@FindBy(xpath = "//div[@class='container text-center']/div/p")
	private WebElement MessageDisplay;
	
	public String MessageDisplay(){
		return MessageDisplay.getText();
	}
	
	@FindBy(xpath = "//td[contains(text(),'Electricity')]//ancestor::tbody//tr[4]//td[3]")
	private WebElement NumberOfUnitsDisplay;
	
	public String NumberOfUnitsDisplay(){
		return NumberOfUnitsDisplay.getText();
	}
	
	

}
