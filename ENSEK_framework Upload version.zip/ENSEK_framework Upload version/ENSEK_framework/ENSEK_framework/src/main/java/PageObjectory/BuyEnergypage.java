package PageObjectory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.baseUtils;

public class BuyEnergypage  extends baseUtils {

	public BuyEnergypage(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Buy energy »')]")
	private WebElement BuyEnergy;
	
	public void BuyEnergybtn() {
		BuyEnergy.click();
	}
	
	
	@FindBy(xpath = "//h2[contains(text(),'Buy Energy')]")
	private WebElement BuyEnergyDisplay;
	
	public String BuyEnergyDisplay(){
		return BuyEnergyDisplay.getText();
	}

}
