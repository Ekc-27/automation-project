package Utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import BaseClass.baseUtils;

public class util extends baseUtils{

	public util(WebDriver driver) {
		baseUtils.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void SelectDropdown(WebElement element, String value) {
		Select userroledropdown = new Select(element);
		userroledropdown.selectByVisibleText(value);
		System.out.println("Text from dropdown selected successfully");
	}

	public void SelectDropdownByValue(WebElement element, String value) {
		Select userroledropdown = new Select(element);
		userroledropdown.selectByValue(value);
		System.out.println("Value from dropdown selected successfully");
	}

	

	public void datepicker(List<WebElement> element) {
		DateFormat dateFormat = new SimpleDateFormat("d");
		Date todaydate = new Date();
		String today = dateFormat.format(todaydate);

		List<WebElement> columns = element;
		for (WebElement cell : columns) {
			System.out.println("Cell display as : " + cell.getText());
			if (cell.getText().equals(today)) {
				cell.click();
				break;
			}
		}
	}

	public void capturewebtable(List<WebElement> Table) {

		List<WebElement> col = Table;
		int count = col.size();
		System.out.println("Total No of columns are : " + count);

		for (int i = 1; i < count; i++) {
			String data = col.get(i).getText();
			System.out.println("data display as : " + data);
		}
	}
}
