package BaseClass;

import org.openqa.selenium.WebDriver;

public class baseUtils {
	protected static WebDriver driver;
}
